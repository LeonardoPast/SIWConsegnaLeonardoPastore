package it.uniroma3.siw.utils;


import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import it.uniroma3.siw.model.Artist;
import it.uniroma3.siw.model.Movie;
import it.uniroma3.siw.model.Photo;

public class FileUploadUtil {

	public static void saveFile(String uploadDir, String fileName,
			MultipartFile multipartFile) throws IOException {
		Path uploadPath = Paths.get(uploadDir);

		if (!Files.exists(uploadPath)) {
			Files.createDirectories(uploadPath);
		}

		try (InputStream inputStream = multipartFile.getInputStream()) {
			Path filePath = uploadPath.resolve(fileName);
			Files.copy(inputStream, filePath, StandardCopyOption.REPLACE_EXISTING);
		} catch (IOException ioe) {        
			throw new IOException("Could not save image file: " + fileName, ioe);
		}      
	}


	//util per eliminare foto e cartella delle foto di un film
	public static void deleteFile(Movie movie) throws IOException {
		List<Photo> foto;
		foto = movie.getFoto();
		String subPath = new String();
		String abb = new String();
		for(Photo f: foto) {
			String percorso =  f.getFileName();
			abb  =  f.getFileName();
			subPath =  f.getRelativePath();
			Path delPath = Paths.get(percorso);
			Files.delete(delPath);

		}
		String id =Long.toString(movie.getId());
		String result = abb.split(id)[0];
		result= result + "/" + id;
		Path delPath = Paths.get(result);
		Files.delete(delPath);
	} 



	//util per eliminare foto e cartella delle foto di un artista
	public static void deleteFileArtista(Artist artista) throws IOException {

		String percorso = "C:\\Users\\admin\\Documents\\workspace-spring-tool-suite-4-4.17.2.RELEASE\\siw-movie-0\\" + artista.getFotoPath();
		Path delPath = Paths.get(percorso);
		Files.delete(delPath);

		List<String> partiPercorso = new ArrayList<String>();
		for(String s : percorso.split("\\\\"))
			partiPercorso.add(s);

		String alfa = "C:\\\\Users\\\\admin\\\\Documents\\\\workspace-spring-tool-suite-4-4.17.2.RELEASE\\\\siw-movie-0\\\\artist-photos\\\\"+ partiPercorso.get(partiPercorso.size()-1);
		delPath = Paths.get(alfa);
		Files.delete(delPath); 

	} 

 
    
}