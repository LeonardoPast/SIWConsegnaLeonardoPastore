package it.uniroma3.siw.model;

import java.beans.Transient;
import java.util.List;
import java.util.Objects;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "users") // cambiamo nome perchè in postgres user e' una parola riservata
public class User {
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

	@NotNull()
	@NotBlank
	private String name;
	
	public List<Review> getRecensioniScritte() {
		return recensioniScritte;
	}

	public void setRecensioniScritte(List<Review> recensioniScritte) {
		this.recensioniScritte = recensioniScritte;
	}

	@NotNull()
	@NotBlank
	private String surname;
	
	@NotNull()
	@NotBlank
	private String email;

	//
	private String photos;
	private String photosImagePath;
	public String getPhotos() {
		return photos;
	}

	public void setPhotos(String photos) {
		this.photos = photos;
	}
	
	   @Transient
	    public String getPhotosImagePath() {
	        if (photos == null || id == null) return null;
	         
	        return photosImagePath;
	    }
//
	@OneToMany
	private List<Review> recensioniScritte;
	
    @Override
	public int hashCode() {
		return Objects.hash(email, surname);
	}

    //equals su email e cognome
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		return Objects.equals(email, other.email) && Objects.equals(surname, other.surname);
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getSurname() {
		return surname;
	}
	
	public void setSurname(String surname) {
		this.surname = surname;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}

	public void setPhotosImagePath(String photosImagePath) {
		this.photosImagePath = photosImagePath;
	}
}