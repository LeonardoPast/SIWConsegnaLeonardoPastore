package it.uniroma3.siw.model;

import java.time.LocalDate;
import java.util.List;
import java.util.Objects;

import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Entity
public class Artist {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	
	private Long id;
	
	@NotNull()
	@NotBlank
	private String nome;
	
	@NotNull()
	@NotBlank
	private String cognome;
	

	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate data_nascita;
	
	
	@ManyToMany
	private List<Movie> moviesActed;
	
	@OneToMany(mappedBy= "director")
	private List<Movie> moviesDirected;

	private String fotoPath;
	
	public String getFotoPath() {
		return fotoPath;
	}
	public void setFotoPath(String fotoPath) {
		this.fotoPath = fotoPath;
	}
	public LocalDate getData_nascita() {
		return data_nascita;
	}
	public void setData_nascita(LocalDate data_nascita) {
		this.data_nascita = data_nascita;
	}
	public LocalDate getData_morte() {
		return data_morte;
	}
	public void setData_morte(LocalDate data_morte) {
		this.data_morte = data_morte;
	}
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate data_morte;
	

	public List<Movie> getMoviesActed() {
		return moviesActed;
	}
	public void setMoviesActed(List<Movie> moviesActed) {
		this.moviesActed = moviesActed;
	}
	public List<Movie> getMoviesDirected() {
		return moviesDirected;
	}
	public void setMoviesDirected(List<Movie> moviesDirected) {
		this.moviesDirected = moviesDirected;
	}
	@Override
	public int hashCode() {
		return Objects.hash(cognome, id, nome);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Artist other = (Artist) obj;
		return 	 Objects.equals(nome, other.nome) && Objects.equals(cognome, other.cognome);
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCognome() {
		return cognome;
	}
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	
}
